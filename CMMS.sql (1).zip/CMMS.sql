-- phpMyAdmin SQL Dump
-- version 4.4.15.9
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 18, 2020 at 10:48 AM
-- Server version: 5.6.37
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `CMMS`
--

-- --------------------------------------------------------

--
-- Table structure for table `Equipment`
--

CREATE TABLE IF NOT EXISTS `Equipment` (
  `Asset_ID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Serial_number` int(11) NOT NULL,
  `Model_number` int(11) NOT NULL,
  `Model_name` varchar(255) NOT NULL,
  `Manufacturer` varchar(11) NOT NULL,
  `Installation_date` date NOT NULL,
  `Warranty_expires` date NOT NULL,
  `Facility` varchar(11) NOT NULL,
  `Building` int(11) NOT NULL,
  `Floor` int(11) NOT NULL,
  `Department` varchar(11) NOT NULL,
  `Scrapping_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Technicians`
--

CREATE TABLE IF NOT EXISTS `Technicians` (
  `SSN` int(30) NOT NULL,
  `Phone_number` int(30) NOT NULL,
  `Company` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Work_on`
--

CREATE TABLE IF NOT EXISTS `Work_on` (
  `SSN` int(11) NOT NULL,
  `Order_number` int(11) NOT NULL,
  `Number_of_hours` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Work_orders`
--

CREATE TABLE IF NOT EXISTS `Work_orders` (
  `Order_number` int(11) NOT NULL,
  `Asset_ID` int(11) NOT NULL,
  `Name` varchar(11) NOT NULL,
  `Status` varchar(11) NOT NULL,
  `Creation__date` date NOT NULL,
  `Demand/PM` varchar(11) NOT NULL,
  `Start_date` date NOT NULL,
  `Due_date` date NOT NULL,
  `PM_date` date NOT NULL,
  `PM_frequency` varchar(11) NOT NULL,
  `Priority` varchar(11) NOT NULL,
  `Description` text NOT NULL,
  `Associations` varchar(11) NOT NULL,
  `Demand_cost` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Equipment`
--
ALTER TABLE `Equipment`
  ADD PRIMARY KEY (`Asset_ID`);

--
-- Indexes for table `Technicians`
--
ALTER TABLE `Technicians`
  ADD PRIMARY KEY (`SSN`);

--
-- Indexes for table `Work_on`
--
ALTER TABLE `Work_on`
  ADD KEY `SSN` (`SSN`),
  ADD KEY `Order_number` (`Order_number`);

--
-- Indexes for table `Work_orders`
--
ALTER TABLE `Work_orders`
  ADD PRIMARY KEY (`Order_number`),
  ADD KEY `Asset ID` (`Asset_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Work_on`
--
ALTER TABLE `Work_on`
  ADD CONSTRAINT `work_on_ibfk_1` FOREIGN KEY (`SSN`) REFERENCES `Technicians` (`SSN`),
  ADD CONSTRAINT `work_on_ibfk_2` FOREIGN KEY (`Order_number`) REFERENCES `Work_orders` (`Order_number`);

--
-- Constraints for table `Work_orders`
--
ALTER TABLE `Work_orders`
  ADD CONSTRAINT `work_orders_ibfk_1` FOREIGN KEY (`Asset_ID`) REFERENCES `Equipment` (`Asset_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
